export default class MyWebLogTracker {

}